    <!-- Booking Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="booking p-5">
                <div class="row g-5 align-items-center">
                    <div class="col-md-6 text-white">
                        <h6 class="text-white text-uppercase">Booking</h6>
                        <h1 class="text-white mb-4">Online Booking</h1>
                        <p class="mb-4">Online Booking at Vindhya Prayag Hotel
Easily book your stay at Vindhya Prayag Hotel through our user-friendly online platform. Browse available rooms and select your preferred dates with just a few clicks.</p>
                        <p class="mb-4">Enjoy the convenience of secure payment options and receive instant booking confirmation, ensuring a seamless experience from start to finish.</p>
                        <a class="btn btn-outline-light py-3 px-5 mt-2" href="">Read More</a>
                    </div>
                    <div class="col-md-6">
                        <h1 class="text-white mb-4">Book A Dormitory</h1>
                        <form action= "send_mail.php" method ="post">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control bg-transparent" id="name" name="name" placeholder="Your Name" required>
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                
                                
                                                             
                                 <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control bg-transparent" id="email" name="email" placeholder="Your Email" required>
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                
                                
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control bg-transparent" id="start" name="start" placeholder="Your Start Date & Time" required>
                                        <label for="email">Start Date & Time</label>
                                    </div>
                                </div>
 
                                
                                <div class="col-md-6">
                                    <div class="form-floating date" id="date3" data-target-input="nearest">
                                        <input type="date" class="form-control bg-transparent datetimepicker-input" id="end" name="end" placeholder="End Date & Time" data-target="#date3" data-toggle="datetimepicker" />
                                        <label for="datetime">End Date & Time</label>
                                    </div>
                                </div>
                                
                            
                                
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control bg-transparent" id="phone" name="phone" placeholder="Your Phone">
                                        <label for="name">Your Phone</label>
                                    </div>
                                </div>
                                
                                 <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select" id="subject" name="subject" aria-label="Default select example">
  <option selected>Choose Dormitory</option>
  <option value="Dormitory">Dormitory</option>
  <option value="Amrit Snan">Amrit Snan</option>
</select>
                                    </div>
                                </div>
                                
                                
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control bg-transparent" placeholder="Special Request" id="message" name="message" style="height: 100px"></textarea>
                                        <label for="message">Special Request</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-outline-light w-100 py-3" type="submit">Book Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Booking Start -->
