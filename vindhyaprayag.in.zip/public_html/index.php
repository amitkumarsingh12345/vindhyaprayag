<!DOCTYPE php>
<php lang="en">

<head>
    <meta charset="utf-8">
    <title>Vindhya Prayag</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
     <!--Sweet Alert-->
     <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.min.css" rel="stylesheet">
     
     
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

 

 <!--Topbar Start-->
  <?php include_once 'include/topbar.php'; ?>
    <!--Topbar End-->

    <!-- Navbar & Hero Start -->
    <div class="container-fluid position-relative p-0">
        
 <!--Footer Start-->
  <?php include_once 'include/header.php'; ?>
    <!--Footer End-->
    
    
        <div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                        <h1 class="display-3 text-white mb-3 animated slideInDown">Dormitory + Double bed</h1>
                        <p class="fs-4 text-white mb-4 animated slideInDown">Cozy Dormitory with Double Bed – Comfortable, Affordable, and Perfect for Relaxing!</p>
                        <div class="position-relative w-75 mx-auto animated slideInDown">
                            <input class="form-control border-0 rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Vindhya Prayag Hotel...">
                            <button type="button" class="btn btn-primary rounded-pill py-2 px-4 position-absolute top-0 end-0 me-2" style="margin-top: 7px;">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="img/n2.jpeg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 class="mb-4">Welcome to <span class="text-primary">Vindhya Prayag</span></h1>
                    <p class="mb-4">Vindhya Prayag Dormitory offers a blend of shared dormitory spaces and private double beds, ensuring comfort, privacy, and a peaceful stay, perfect for travelers seeking affordability and relaxation.</p>
                    <p class="mb-4">Vindhya Prayag Dormitory offers cozy dorms and private double beds, blending comfort and affordability for a relaxing stay.</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Affordable Comfort</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Convenient Location</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Modern Amenities</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Relaxing Atmosphere</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Flexible Stay Options</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Secure and Safe</p>
                        </div>
                    </div>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="about.php">Read More</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Services</h6>
                <h1 class="mb-5">Choose Our Dormitory</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded pt-3">
                        <div class="p-4">
                           <img src="img/n3.jpeg" class="img-fluid mb-3" alt="...">
                            <h5>Dormitory</h5>
                            <p>Charge For Normal Days - 1799 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>
                              <hr/>
                    <p>
                        <b>Room Size - </b>
                        <span>16*12</span>
                    </p>
                        </div>
                    </div>
                </div>
             
                             <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded pt-3">
                        <div class="p-4">
                           <img src="img/n2.jpeg" class="img-fluid mb-3" alt="...">
                            <h5>Amrit Snan</h5>
                            <p>Charge For Normal Days - 3199 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>
                              <hr/>
                    <p>
                        <b>Room Size - </b>
                        <span>20*12</span>
                    </p>
                        </div>
                    </div>
                </div>
                
                <!--                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--    <div class="service-item rounded pt-3">-->
                <!--        <div class="p-4">-->
                <!--           <img src="img/v3.jpeg" class="img-fluid mb-3" alt="...">-->
                <!--            <h5>Delux (Shahi Snan)</h5>-->
                <!--            <p>Charge For Normal Days - 25000 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>-->
                <!--              <hr/>-->
                <!--    <p>-->
                <!--        <b>Room Size - </b>-->
                <!--        <span>16*12</span>-->
                <!--    </p>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                
                
                <!--              <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--    <div class="service-item rounded pt-3">-->
                <!--        <div class="p-4">-->
                <!--           <img src="img/v4.jpeg" class="img-fluid mb-3" alt="...">-->
                <!--            <h5>Super Delux <br/>(Shahi Snan)</h5>-->
                <!--            <p>Charge For Normal Days - 30000 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>-->
                <!--              <hr/>-->
                <!--    <p>-->
                <!--        <b>Room Size - </b>-->
                <!--        <span>20*12</span>-->
                <!--    </p>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- Destination Start -->
    <div class="container-xxl py-5 destination">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Destination</h6>
                <h1 class="mb-5">Popular Destination</h1>
            </div>
            <div class="row g-3">
                <div class="col-lg-7 col-md-6">
                    <div class="row g-3">
                        <div class="col-lg-12 col-md-12 wow zoomIn" data-wow-delay="0.1s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="img/caros1.jpeg" alt="">
                                <!--<img class="img-fluid" src="img/vb5.jpeg" alt="">-->
                                <div class="bg-white text-danger fw-bold position-absolute top-0 start-0 m-3 py-1 px-2">30% OFF</div>
                                <div class="bg-white text-primary fw-bold position-absolute bottom-0 end-0 m-3 py-1 px-2">India</div>
                            </a>
                        </div>
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="img/abt.jpeg" alt="">
                                <div class="bg-white text-danger fw-bold position-absolute top-0 start-0 m-3 py-1 px-2">25% OFF</div>
                                <div class="bg-white text-primary fw-bold position-absolute bottom-0 end-0 m-3 py-1 px-2">India</div>
                            </a>
                        </div>
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="img/abt2.jpeg" alt="">
                                <div class="bg-white text-danger fw-bold position-absolute top-0 start-0 m-3 py-1 px-2">35% OFF</div>
                                <div class="bg-white text-primary fw-bold position-absolute bottom-0 end-0 m-3 py-1 px-2">India</div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-6 wow zoomIn" data-wow-delay="0.7s" style="min-height: 350px;">
                    <a class="position-relative d-block h-100 overflow-hidden" href="">
                        <img class="img-fluid position-absolute w-100 h-100" src="img/n3.jpeg" alt="" style="object-fit: cover;">
                        <div class="bg-white text-danger fw-bold position-absolute top-0 start-0 m-3 py-1 px-2">20% OFF</div>
                        <div class="bg-white text-primary fw-bold position-absolute bottom-0 end-0 m-3 py-1 px-2">India</div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Destination Start -->


   <!-- Package Start -->
   <!-- <div class="container-xxl py-5">-->
   <!--     <div class="container">-->
   <!--         <div class="text-center wow fadeInUp" data-wow-delay="0.1s">-->
   <!--             <h6 class="section-title bg-white text-center text-primary px-3">Food Menu</h6>-->
   <!--             <h1 class="mb-5">Most Popular Items</h1>-->
   <!--         </div>-->
   <!--         <div class="row g-4 justify-content-center">-->
   <!--             <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--                 <div class="package-item">-->
   <!--                     <div class="overflow-hidden">-->
   <!--                         <img class="img-fluid" src="img/m9.jpeg" alt="">-->
   <!--                     </div>-->
 
   <!--                     <div class="text-center p-4">-->
   <!--                         <h3 class="mb-0">Breakfast</h3>-->
   <!--                         <div class="mb-3">-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                         </div>-->
   <!--                         <p>A wholesome start to your day with delicious, energizing options.</p>-->
   <!--                         <div class="d-flex justify-content-center mb-2">-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">07:00AM - </a>-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">09:00AM</a>-->
   <!--                         </div>-->
   <!--                     </div>-->
   <!--                 </div>-->
   <!--             </div>-->
            
 
                
   <!--             <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--                 <div class="package-item">-->
   <!--                     <div class="overflow-hidden">-->
   <!--                         <img class="img-fluid" src="img/m2.jpeg" alt="">-->
   <!--                     </div>-->
 
   <!--                     <div class="text-center p-4">-->
   <!--                         <h3 class="mb-0">Lunch</h3>-->
   <!--                         <div class="mb-3">-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                         </div>-->
   <!--                         <p>A hearty, balanced meal to refresh and energize your day.</p>-->
   <!--                         <div class="d-flex justify-content-center mb-2">-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">11:00AM - </a>-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;"> 02:00PM</a>-->
   <!--                         </div>-->
   <!--                     </div>-->
   <!--                 </div>-->
   <!--             </div>-->
                
                
   <!--                     <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--                 <div class="package-item">-->
   <!--                     <div class="overflow-hidden">-->
   <!--                         <img class="img-fluid" src="img/m7.jpeg" alt="">-->
   <!--                     </div>-->
   <!--                                     <div class="text-center p-4">-->
   <!--                         <h3 class="mb-0">Dinner</h3>-->
   <!--                         <div class="mb-3">-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                             <small class="fa fa-star text-primary"></small>-->
   <!--                         </div>-->
   <!--                         <p>A comforting, flavorful meal to end your day on a high.</p>-->
   <!--                         <div class="d-flex justify-content-center mb-2">-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">07:00PM - </a>-->
   <!--                             <a href="#" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">10:30PM</a>-->
   <!--                         </div>-->
   <!--                     </div>-->
   <!--                 </div>-->
   <!--             </div>-->
                
                
   <!--         </div>-->
   <!--     </div>-->
   <!-- </div>-->
    <!-- Package End -->



 <!--Booking Start-->
  <?php include_once 'include/online_booking.php'; ?>
    <!--Booking End-->
    

    <!-- Process Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center pb-4 wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Process</h6>
                <h1 class="mb-5">3 Easy Steps</h1>
            </div>
            <div class="row gy-5 gx-4 justify-content-center">
                <div class="col-lg-4 col-sm-6 text-center pt-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="position-relative border border-primary pt-5 pb-4 px-4">
                        <div class="d-inline-flex align-items-center justify-content-center bg-primary rounded-circle position-absolute top-0 start-50 translate-middle shadow" style="width: 100px; height: 100px;">
                            <i class="fa fa-globe fa-3x text-white"></i>
                        </div>
                        <h5 class="mt-4">Choose A Delux</h5>
                        <hr class="w-25 mx-auto bg-primary mb-1">
                        <hr class="w-50 mx-auto bg-primary mt-0">
                        <p class="mb-0">Choose a Deluxe Room for Unmatched Comfort, Style, and a Truly Relaxing Stay!</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 text-center pt-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="position-relative border border-primary pt-5 pb-4 px-4">
                        <div class="d-inline-flex align-items-center justify-content-center bg-primary rounded-circle position-absolute top-0 start-50 translate-middle shadow" style="width: 100px; height: 100px;">
                            <i class="fa fa-rupee-sign fa-3x text-white"></i>
                            <!--<i class="fa fa-dollar-sign fa-3x text-white"></i>-->
                        </div>
                        <h5 class="mt-4">Pay Online</h5>
                        <hr class="w-25 mx-auto bg-primary mb-1">
                        <hr class="w-50 mx-auto bg-primary mt-0">
                        <p class="mb-0">Secure and Convenient: Pay Online for a Hassle-Free Booking Experience!</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 text-center pt-4 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="position-relative border border-primary pt-5 pb-4 px-4">
                        <div class="d-inline-flex align-items-center justify-content-center bg-primary rounded-circle position-absolute top-0 start-50 translate-middle shadow" style="width: 100px; height: 100px;">
                            <i class="fa fa-plane fa-3x text-white"></i>
                        </div>
                        <h5 class="mt-4">Enjoy</h5>
                        <hr class="w-25 mx-auto bg-primary mb-1">
                        <hr class="w-50 mx-auto bg-primary mt-0">
                        <p class="mb-0">Enjoy Unforgettable Moments – Your Perfect Escape Awaits!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Process Start -->


    <!-- Team Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Guide</h6>
                <h1 class="mb-5">Meet Our Guide</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/vijay.jpeg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -19px;">
                            <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Vijay</h5>
                            <small>Designation</small>
                        </div>
                    </div>
                </div>
                <!--<div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">-->
                <!--    <div class="team-item">-->
                <!--        <div class="overflow-hidden">-->
                <!--            <img class="img-fluid" src="img/team-2.jpg" alt="">-->
                <!--        </div>-->
                <!--        <div class="position-relative d-flex justify-content-center" style="margin-top: -19px;">-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                <!--        </div>-->
                <!--        <div class="text-center p-4">-->
                <!--            <h5 class="mb-0">Neha Ray</h5>-->
                <!--            <small>Designation</small>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">-->
                <!--    <div class="team-item">-->
                <!--        <div class="overflow-hidden">-->
                <!--            <img class="img-fluid" src="img/team-3.jpg" alt="">-->
                <!--        </div>-->
                <!--        <div class="position-relative d-flex justify-content-center" style="margin-top: -19px;">-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                <!--        </div>-->
                <!--        <div class="text-center p-4">-->
                <!--            <h5 class="mb-0">Karan Kumar</h5>-->
                <!--            <small>Designation</small>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">-->
                <!--    <div class="team-item">-->
                <!--        <div class="overflow-hidden">-->
                <!--            <img class="img-fluid" src="img/team-4.jpg" alt="">-->
                <!--        </div>-->
                <!--        <div class="position-relative d-flex justify-content-center" style="margin-top: -19px;">-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                <!--            <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                <!--        </div>-->
                <!--        <div class="text-center p-4">-->
                <!--            <h5 class="mb-0">Sneha Maurya </h5>-->
                <!--            <small>Designation</small>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="section-title bg-white text-center text-primary px-3">Testimonial</h6>
                <h1 class="mb-5">Our Clients Say!!!</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="bg-white rounded-circle shadow p-1 mx-auto mb-3" src="img/testimonial-1.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Kinzi</h5>
                    <p>Uttar Pradesh, India</p>
                    <p class="mb-0">Our Clients Say: Exceptional service, unforgettable experiences, and the perfect stay – see why they choose us every time!</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="bg-white rounded-circle shadow p-1 mx-auto mb-3" src="img/testimonial-2.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">John bhai</h5>
                    <p>Uttar Pradesh, India</p>
                    <p class="mt-2 mb-0">Our Clients Say: Exceptional service, unforgettable experiences, and the perfect stay – see why they choose us every time!</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="bg-white rounded-circle shadow p-1 mx-auto mb-3" src="img/testimonial-3.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Peter</h5>
                    <p>Uttar Pradesh, India</p>
                    <p class="mt-2 mb-0">Our Clients Say: Exceptional service, unforgettable experiences, and the perfect stay – see why they choose us every time!</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="bg-white rounded-circle shadow p-1 mx-auto mb-3" src="img/testimonial-4.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">John Doe</h5>
                    <p>Uttar Pradesh, India</p>
                    <p class="mt-2 mb-0">Our Clients Say: Exceptional service, unforgettable experiences, and the perfect stay – see why they choose us every time!</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->
        

  <!--Footer Start-->
  <?php include_once 'include/footer.php'; ?>
    <!--Footer End-->
   

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    
          <!--Sweet Alert CDN       -->
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.min.js"></script>


</body>

</html>


<?php
$bookingSuccess = $_COOKIE['electronic']; 

if ($bookingSuccess) {
    echo "
    <script>
       Swal.fire({
    icon: 'success',
    title: 'Message Send Successful!',
    text: 'Your message has been successfully confirmed.',
    confirmButtonText: 'OK'
}).then((result) => {
    if (result.isConfirmed) {
        document.cookie = 'electronic=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    }
});
    </script>
    ";
}
?>