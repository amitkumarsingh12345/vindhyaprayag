<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
      $start = htmlspecialchars($_POST['start']);
    $end = htmlspecialchars($_POST['end']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);
    

    $to = "vindhyapraya@gmail.com"; 
    $subject_line = "Contact Form Submission: " . $subject;

    $email_body = "You have received a new message from your website contact form.\n\n";
    $email_body .= "Name: " . $name . "\n";
    $email_body .= "Email: " . $email . "\n";
    $email_body .= "Phone: " . $phone . "\n";
    $email_body .= "Satrt Date & Time: " . $start . "\n";
    $email_body .= "End Date & Time: " . $end . "\n";
    $email_body .= "Subject: " . $subject . "\n";
    $email_body .= "Message: " . $message . "\n";

    // Set the headers for the email
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send the email
    if (mail($to, $subject_line, $email_body, $headers)) {
        setcookie("electronic", true);
        echo "<p>Thank you for contacting us, " . $name . ". Your message has been sent successfully!</p>";
    } else {
        echo "<p>Sorry, there was an issue sending your message. Please try again later.</p>";
    }
       header("Location: index.php");
        exit();
}
?>


